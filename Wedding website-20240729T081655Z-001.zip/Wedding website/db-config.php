<?php
$servername = "sci-mysql.lboro.ac.uk";
$dbname = "coa123wdb";
$username = "coa123wuser";
$password = "grt64dkh!@2FD";
?>